package net.chekitech.jumiacompare;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.applovin.mediation.MaxError;
import com.squareup.picasso.Picasso;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.mediation.ads.MaxInterstitialAd;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;
import android.annotation.SuppressLint;
import android.os.Handler;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.facebook.ads.*;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.concurrent.TimeUnit;

public class MoroccoDetailActivity extends AppCompatActivity implements MaxAdViewAdListener {

    private MaxAdView adView;
    private MaxInterstitialAd interstitialAd;
    private int retryAttempt;

    TextView mTitleTv, mCompanyTv, mLocationTv, mMoneyTv, mContractTv, mPostingTv, mRdescTv, mQualdescTv, mApplyTv;
    ImageView mImageIv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_morocco_detail);

        // Please make sure to set the mediation provider value to "max" to ensure proper functionality
        AppLovinSdk.getInstance( this ).setMediationProvider( "max" );
        AppLovinSdk.initializeSdk( this, new AppLovinSdk.SdkInitializationListener() {
            @Override
            public void onSdkInitialized(final AppLovinSdkConfiguration configuration)
            {
                // AppLovin SDK is initialized, start loading ads

                createBannerAd();
                createInterstitialAd();

            }
        } );

        // ---------------------------------------------------------------------------------------------------------------

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Morocco Shopping");

        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        mTitleTv = findViewById(R.id.titleTv);
        mCompanyTv = findViewById(R.id.companyTv);
        mLocationTv = findViewById(R.id.locationTv);
        mMoneyTv = findViewById(R.id.moneyTv);
        mContractTv = findViewById(R.id.contractTv);
        mPostingTv = findViewById(R.id.postingTv);
        mRdescTv = findViewById(R.id.RdescTv);
        mQualdescTv = findViewById(R.id.QualdescTv);
        mApplyTv = findViewById(R.id.applyTv);
        mImageIv = findViewById(R.id.imageView);

        String image = getIntent().getStringExtra("image");
        String title = getIntent().getStringExtra("title");
        String company = getIntent().getStringExtra("company");

        String money = getIntent().getStringExtra("money");
        String contract = getIntent().getStringExtra("contract");
        String posting = getIntent().getStringExtra("posting");

        String location = getIntent().getStringExtra("location");
        String rdesc = getIntent().getStringExtra("rdesc");
        String qdesc = getIntent().getStringExtra("qdesc");
        String apply = getIntent().getStringExtra("apply");

        mTitleTv.setText(title);
        mCompanyTv.setText(company);
        mLocationTv.setText(location);

        mMoneyTv.setText(money);
        mContractTv.setText(contract);
        mPostingTv.setText(posting);

        mRdescTv.setText(rdesc);
        mQualdescTv.setText(qdesc);
        mApplyTv.setText(apply);
        Picasso.get().load(image).into(mImageIv);
    }

    // =========================================================================================

    void createInterstitialAd() {
        interstitialAd = new MaxInterstitialAd("76581c7825a41aa9", this);
        interstitialAd.setListener(this);

        // Load the first ad
        interstitialAd.loadAd();
    }

    // =========================================================================================
    // -------------------------------------------------------------------------------------------------------------------------------

    @SuppressLint("ResourceAsColor")
    private void createBannerAd() {

        adView = new MaxAdView("4f63acc3df8f1c48", this);
        adView.setListener(this);

        // Stretch to the width of the screen for banners to be fully functional
        int width = ViewGroup.LayoutParams.MATCH_PARENT;

        // Banner height on phones and tablets is 50 and 90, respectively
        int heightPx = getResources().getDimensionPixelSize(R.dimen.banner_height);

        adView.setLayoutParams(new FrameLayout.LayoutParams(width, heightPx));

        // Set background or background color for banners to be fully functional
        adView.setBackgroundColor(R.color.white);

        ViewGroup rootView = findViewById(android.R.id.content);
        rootView.addView(adView);

        // Load the ad
        adView.loadAd();


    }

    // MAX Ad Listener
    @Override
    public void onAdLoaded(final MaxAd maxAd) {

        // Interstitial ad is ready to be shown. interstitialAd.isReady() will now return 'true'

        // Reset retry attempt
        retryAttempt = 0;

        interstitialAd.showAd();

    }

    @Override
    public void onAdClicked(final MaxAd maxAd) {
    }

    @Override
    public void onAdLoadFailed(String adUnitId, MaxError error) {
        // Interstitial ad failed to load
        // We recommend retrying with exponentially higher delays up to a maximum delay (in this case 64 seconds)

        retryAttempt++;
        long delayMillis = TimeUnit.SECONDS.toMillis((long) Math.pow(2, Math.min(6, retryAttempt)));

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                interstitialAd.loadAd();
            }
        }, delayMillis);
    }

    @Override
    public void onAdDisplayFailed(MaxAd ad, MaxError error) {
        // Interstitial ad failed to display. We recommend loading the next ad
        interstitialAd.loadAd();
    }

    @Override
    public void onAdExpanded(final MaxAd maxAd) {
    }

    @Override
    public void onAdCollapsed(final MaxAd maxAd) {
    }

    @Override
    public void onAdDisplayed(final MaxAd maxAd) { /* DO NOT USE - THIS IS RESERVED FOR FULLSCREEN ADS ONLY AND WILL BE REMOVED IN A FUTURE SDK RELEASE */ }

    @Override
    public void onAdHidden(final MaxAd maxAd) {
    }

    // =========================================================================================
    // -------------------------------------------------------------------------------------------------------------------------------

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onDestroy() {
        interstitialAd.destroy();
        super.onDestroy();
    }

}
