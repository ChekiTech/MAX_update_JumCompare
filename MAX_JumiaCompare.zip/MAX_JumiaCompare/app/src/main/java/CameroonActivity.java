package net.chekitech.jumiacompare;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import com.facebook.ads.*;
import android.widget.LinearLayout;
import android.widget.Toast;

public class CameroonActivity extends AppCompatActivity implements MaxAdViewAdListener {

    private MaxAdView adView;

    LinearLayoutManager mLinearLayoutManager;

    RecyclerView mRecyclerView;
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference mRef;
    FirebaseRecyclerAdapter<Model, ViewHolder> firebaseRecyclerAdapter;
    FirebaseRecyclerOptions<Model> options;

    @Override
    protected void onStart() {
        firebaseRecyclerAdapter.startListening();
        super.onStart();
    }

    @Override
    protected void onStop() {
        firebaseRecyclerAdapter.stopListening();
        super.onStop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cameroon);

        // Please make sure to set the mediation provider value to "max" to ensure proper functionality
        AppLovinSdk.getInstance( this ).setMediationProvider( "max" );
        AppLovinSdk.initializeSdk( this, new AppLovinSdk.SdkInitializationListener() {
            @Override
            public void onSdkInitialized(final AppLovinSdkConfiguration configuration)
            {
                // AppLovin SDK is initialized, start loading ads

                createBannerAd();

            }
        } );

        // ---------------------------------------------------------------------------------------------------------------

        TextView butth= findViewById(R.id.home);
        TextView butttan= findViewById(R.id.tan);
        TextView buttoth= findViewById(R.id.oth);

        butth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inth= new Intent(CameroonActivity.this,HomeActivity.class);
                startActivity(inth);
            }
        });

        butttan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(CameroonActivity.this,TanzaniaActivity.class);
                startActivity(int1);
            }
        });

        buttoth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ints= new Intent(CameroonActivity.this,OthercountriesActivity.class);
                startActivity(ints);
            }
        });

        mLinearLayoutManager = new LinearLayoutManager(this);
        mLinearLayoutManager.setReverseLayout(true);
        mLinearLayoutManager.setStackFromEnd(true);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Cameroon");

        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mRef = mFirebaseDatabase.getReference().child("JUMIACAMEROON");

        showData();

    }

    // -------------------------------------------------------------------------------------------------------------------------------

    @SuppressLint("ResourceAsColor")
    private void createBannerAd() {

        adView = new MaxAdView( "4f63acc3df8f1c48", this );
        adView.setListener( this );

        // Stretch to the width of the screen for banners to be fully functional
        int width = ViewGroup.LayoutParams.MATCH_PARENT;

        // Banner height on phones and tablets is 50 and 90, respectively
        int heightPx = getResources().getDimensionPixelSize( R.dimen.banner_height );

        adView.setLayoutParams( new FrameLayout.LayoutParams( width, heightPx ) );

        // Set background or background color for banners to be fully functional
        adView.setBackgroundColor( R.color.white );

        ViewGroup rootView = findViewById( android.R.id.content );
        rootView.addView( adView );

        // Load the ad
        adView.loadAd();

    }

    // MAX Ad Listener
    @Override
    public void onAdLoaded(final MaxAd maxAd) {}

    @Override
    public void onAdClicked(final MaxAd maxAd) {}

    @Override
    public void onAdLoadFailed(String adUnitId, MaxError error) {

    }

    @Override
    public void onAdDisplayFailed(MaxAd ad, MaxError error) {

    }

    @Override
    public void onAdExpanded(final MaxAd maxAd) {}

    @Override
    public void onAdCollapsed(final MaxAd maxAd) {}

    @Override
    public void onAdDisplayed(final MaxAd maxAd) { /* DO NOT USE - THIS IS RESERVED FOR FULLSCREEN ADS ONLY AND WILL BE REMOVED IN A FUTURE SDK RELEASE */ }

    @Override
    public void onAdHidden(final MaxAd maxAd) { /* DO NOT USE - THIS IS RESERVED FOR FULLSCREEN ADS ONLY AND WILL BE REMOVED IN A FUTURE SDK RELEASE */ }


    // -------------------------------------------------------------------------------------------------------------------------------

    private void showData() {

        options = new FirebaseRecyclerOptions.Builder<Model>().setQuery(mRef, Model.class).build();

        firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Model, ViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull Model model) {
                holder.setDetails(getApplicationContext(), model.getTitle(), model.getCompany(), model.getLocation(), model.getMoney(), model.getContract(), model.getPosting(), model.getRdesc(), model.getQdesc(), model.getJlink(), model.getKlink(), model.getApply(), model.getVisa(), model.getImage2(), model.getImage3(), model.getImage4(), model.getImage());

            }

            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

                View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row, parent, false);
                ViewHolder viewHolder = new ViewHolder(itemView);

                viewHolder.setOnClickListener(new ViewHolder.ClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {

                        String mTitle = getItem(position).getTitle();
                        String mComp = getItem(position).getCompany();
                        String mLoc = getItem(position).getLocation();

                        String mMon = getItem(position).getMoney();
                        String mCon = getItem(position).getContract();
                        String mPos = getItem(position).getPosting();

                        String mRdesc = getItem(position).getRdesc();
                        String mQdesc = getItem(position).getQdesc();
                        String mApply = getItem(position).getApply();
                        String mImage = getItem(position).getImage();

                        Intent intent = new Intent(view.getContext(), CameroonDetailActivity.class);
                        intent.putExtra("title", mTitle);
                        intent.putExtra("company", mComp);
                        intent.putExtra("location", mLoc);

                        intent.putExtra("money", mMon);
                        intent.putExtra("contract", mCon);
                        intent.putExtra("posting", mPos);

                        intent.putExtra("rdesc", mRdesc);
                        intent.putExtra("qdesc", mQdesc);
                        intent.putExtra("apply", mApply);
                        intent.putExtra("image", mImage);
                        startActivity(intent);

                    }

                    @Override
                    public void onItemLongClick(View view, int position) {

                    }
                });

                return viewHolder;
            }

        };

        mRecyclerView.setLayoutManager(mLinearLayoutManager);
        firebaseRecyclerAdapter.startListening();
        mRecyclerView.setAdapter(firebaseRecyclerAdapter);

    }

    private void firebaseSearch(String searchText) {
        String quary = searchText.toLowerCase();
        Query firebaseSearchQuery = mRef.orderByChild("search").startAt(quary).endAt(quary + "\uf8ff");
        options = new FirebaseRecyclerOptions.Builder<Model>().setQuery(firebaseSearchQuery, Model.class).build();

        firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Model, ViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull Model model) {
                holder.setDetails(getApplicationContext(), model.getTitle(), model.getCompany(), model.getLocation(), model.getMoney(), model.getContract(), model.getPosting(), model.getRdesc(), model.getQdesc(), model.getJlink(), model.getKlink(), model.getApply(), model.getVisa(), model.getImage2(), model.getImage3(), model.getImage4(), model.getImage());

            }

            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

                View itemview = LayoutInflater.from(parent.getContext()).inflate(R.layout.row, parent, false);
                ViewHolder viewHolder = new ViewHolder(itemview);


                viewHolder.setOnClickListener(new ViewHolder.ClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {


                        String mTitle = getItem(position).getTitle();
                        String mComp = getItem(position).getCompany();
                        String mLoc = getItem(position).getLocation();

                        String mMon = getItem(position).getMoney();
                        String mCon = getItem(position).getContract();
                        String mPos = getItem(position).getPosting();
                        String mImage = getItem(position).getImage();

                        String mRdesc = getItem(position).getRdesc();
                        String mQdesc = getItem(position).getQdesc();
                        String mApply = getItem(position).getApply();

                        Intent intent = new Intent(view.getContext(), CameroonDetailActivity.class);
                        intent.putExtra("title", mTitle);
                        intent.putExtra("company", mComp);
                        intent.putExtra("location", mLoc);

                        intent.putExtra("money", mMon);
                        intent.putExtra("contract", mCon);
                        intent.putExtra("posting", mPos);
                        intent.putExtra("image", mImage);

                        intent.putExtra("rdesc", mRdesc);
                        intent.putExtra("qdesc", mQdesc);
                        intent.putExtra("apply", mApply);
                        startActivity(intent);
                    }

                    @Override
                    public void onItemLongClick(View view, int position) {

                    }
                });

                return viewHolder;
            }
        };

        mRecyclerView.setLayoutManager(mLinearLayoutManager);
        firebaseRecyclerAdapter.startListening();
        mRecyclerView.setAdapter(firebaseRecyclerAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        MenuItem item = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(item);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                firebaseSearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                firebaseSearch(newText);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id==R.id.action_about){
            Toast.makeText(this, "A ChekiTech app", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}