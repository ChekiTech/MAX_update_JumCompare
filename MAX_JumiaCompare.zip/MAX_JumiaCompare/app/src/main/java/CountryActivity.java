package net.chekitech.jumiacompare;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import android.content.Intent;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.mediation.ads.MaxInterstitialAd;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;

import java.util.concurrent.TimeUnit;


public class CountryActivity extends AppCompatActivity implements MaxAdViewAdListener {

    private MaxAdView adView;
    private MaxInterstitialAd interstitialAd;
    private int retryAttempt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country);

        // Please make sure to set the mediation provider value to "max" to ensure proper functionality
        AppLovinSdk.getInstance( this ).setMediationProvider( "max" );
        AppLovinSdk.initializeSdk( this, new AppLovinSdk.SdkInitializationListener() {
            @Override
            public void onSdkInitialized(final AppLovinSdkConfiguration configuration)
            {
                // AppLovin SDK is initialized, start loading ads

                createBannerAd();
                createInterstitialAd();

            }
        } );

        // ---------------------------------------------------------------------------------------------------------------

        CardView buttivo= (CardView) findViewById(R.id.CardViewIvo);
        CardView buttnig= (CardView) findViewById(R.id.CardViewNig);
        CardView buttuga= (CardView) findViewById(R.id.CardViewUga);
        CardView buttgha= (CardView) findViewById(R.id.CardViewGha);
        CardView buttken= (CardView) findViewById(R.id.CardViewKen);
        CardView buttegy= (CardView) findViewById(R.id.CardViewEgy);
        CardView buttsen= (CardView) findViewById(R.id.CardViewSen);
        CardView buttmor= (CardView) findViewById(R.id.CardViewMor);
        CardView butttun= (CardView) findViewById(R.id.CardViewTun);
        CardView buttalg= (CardView) findViewById(R.id.CardViewAlg);
        CardView butteth= (CardView) findViewById(R.id.CardViewEth);
        CardView buttsouth= (CardView) findViewById(R.id.CardViewSouth);
        CardView buttcame= (CardView) findViewById(R.id.CardViewCame);
        CardView butttan= (CardView) findViewById(R.id.CardViewTan);
        CardView buttoth= (CardView) findViewById(R.id.CardViewOth);

        buttivo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intivo= new Intent(CountryActivity.this,MainActivity.class);
                startActivity(intivo);
            }
        });

        buttnig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intnig= new Intent(CountryActivity.this,NigeriaActivity.class);
                startActivity(intnig);
            }
        });

        buttuga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intuga= new Intent(CountryActivity.this,UgandaActivity.class);
                startActivity(intuga);
            }
        });

        buttgha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intgha= new Intent(CountryActivity.this,GhanaActivity.class);
                startActivity(intgha);
            }
        });

        buttken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intken= new Intent(CountryActivity.this,KenyaActivity.class);
                startActivity(intken);
            }
        });

        buttegy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent integy= new Intent(CountryActivity.this,EgyptActivity.class);
                startActivity(integy);
            }
        });

        buttsen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intsen= new Intent(CountryActivity.this,SenegalActivity.class);
                startActivity(intsen);
            }
        });

        buttmor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intmor= new Intent(CountryActivity.this,MoroccoActivity.class);
                startActivity(intmor);
            }
        });

        butttun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inttun= new Intent(CountryActivity.this,TunisiaActivity.class);
                startActivity(inttun);
            }
        });

        buttalg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intalg= new Intent(CountryActivity.this,AlgeriaActivity.class);
                startActivity(intalg);
            }
        });

        butteth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inteth= new Intent(CountryActivity.this,EthiopiaActivity.class);
                startActivity(inteth);
            }
        });

        buttsouth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intsouth= new Intent(CountryActivity.this,SouthafricaActivity.class);
                startActivity(intsouth);
            }
        });

        buttcame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intcame= new Intent(CountryActivity.this,CameroonActivity.class);
                startActivity(intcame);
            }
        });

        butttan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inttan= new Intent(CountryActivity.this,TanzaniaActivity.class);
                startActivity(inttan);
            }
        });

        buttoth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intoth= new Intent(CountryActivity.this,OthercountriesActivity.class);
                startActivity(intoth);
            }
        });

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Jumia Compare");

    }

    // =========================================================================================

    void createInterstitialAd() {
        interstitialAd = new MaxInterstitialAd("76581c7825a41aa9", this);
        interstitialAd.setListener(this);

        // Load the first ad
        interstitialAd.loadAd();
    }

    // =========================================================================================
    // -------------------------------------------------------------------------------------------------------------------------------

    @SuppressLint("ResourceAsColor")
    private void createBannerAd() {

        adView = new MaxAdView("4f63acc3df8f1c48", this);
        adView.setListener(this);

        // Stretch to the width of the screen for banners to be fully functional
        int width = ViewGroup.LayoutParams.MATCH_PARENT;

        // Banner height on phones and tablets is 50 and 90, respectively
        int heightPx = getResources().getDimensionPixelSize(R.dimen.banner_height);

        adView.setLayoutParams(new FrameLayout.LayoutParams(width, heightPx));

        // Set background or background color for banners to be fully functional
        adView.setBackgroundColor(R.color.white);

        ViewGroup rootView = findViewById(android.R.id.content);
        rootView.addView(adView);

        // Load the ad
        adView.loadAd();


    }

    // MAX Ad Listener
    @Override
    public void onAdLoaded(final MaxAd maxAd) {

        // Interstitial ad is ready to be shown. interstitialAd.isReady() will now return 'true'

        // Reset retry attempt
        retryAttempt = 0;

        interstitialAd.showAd();

    }

    @Override
    public void onAdClicked(final MaxAd maxAd) {
    }

    @Override
    public void onAdLoadFailed(String adUnitId, MaxError error) {
        // Interstitial ad failed to load
        // We recommend retrying with exponentially higher delays up to a maximum delay (in this case 64 seconds)

        retryAttempt++;
        long delayMillis = TimeUnit.SECONDS.toMillis((long) Math.pow(2, Math.min(6, retryAttempt)));

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                interstitialAd.loadAd();
            }
        }, delayMillis);
    }

    @Override
    public void onAdDisplayFailed(MaxAd ad, MaxError error) {
        // Interstitial ad failed to display. We recommend loading the next ad
        interstitialAd.loadAd();
    }

    @Override
    public void onAdExpanded(final MaxAd maxAd) {
    }

    @Override
    public void onAdCollapsed(final MaxAd maxAd) {
    }

    @Override
    public void onAdDisplayed(final MaxAd maxAd) { /* DO NOT USE - THIS IS RESERVED FOR FULLSCREEN ADS ONLY AND WILL BE REMOVED IN A FUTURE SDK RELEASE */ }

    @Override
    public void onAdHidden(final MaxAd maxAd) {
    }

    // =========================================================================================
    // -------------------------------------------------------------------------------------------------------------------------------

    @Override
    protected void onDestroy() {
        interstitialAd.destroy();
        super.onDestroy();
    }
}